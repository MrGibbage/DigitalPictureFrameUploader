/* -*-mode:java; c-basic-offset:2; indent-tabs-mode:nil -*- */
/*
Copyright (c) 2006-2011 ymnk, JCraft,Inc. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

  1. Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimer.

  2. Redistributions in binary form must reproduce the above copyright 
     notice, this list of conditions and the following disclaimer in 
     the documentation and/or other materials provided with the distribution.

  3. The names of the authors may not be used to endorse or promote products
     derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL JCRAFT,
INC. OR ANY CONTRIBUTORS TO THIS SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.jcraft.jsch;

/**
 * Provides logging abilities to the library.
 * An application might implement this interface to
 * capture the logging data, or to send it to some
 * destination.
 * <p>
 *   The library provides a default implementation which sends the
 *   output to {@code /dev/null}, i.e. does not do any logging.
 * </p>
 * @see JSch#setLogger
 */
public interface Logger{

  /**
   * Log level constant - the lowest level (only use for debugging).
   */
  public final int DEBUG=0;

  /**
   * Log level constant: The second lowest level, information.
   * Use this to get an overview what happens in the program.
   */
  public final int INFO=1;

  /**
   * Log level constant: the middle level, a warning.
   */
  public final int WARN=2;

  /**
   * Log level constant: the second-highest level, something
   *  occured which should not have.
   */
  public final int ERROR=3;

  /**
   * Log level constant: the highest level: something did get so wrong
   *   that recovering is not possible.
   */
  public final int FATAL=4;


  /**
   * Checks if logging of some level is actually enabled.
   * This will be called by the library before each call
   *  to {@link #log}.
   * @param level one of the log level constants {@link #DEBUG}, {@link #INFO},
   * {@link #WARN}, {@link #ERROR} and {@link #FATAL}.
   */
  public boolean isEnabled(int level);


  /**
   * Logs some message. 
   * @param level one of the log level constants {@link #DEBUG}, {@link #INFO},
   * {@link #WARN}, {@link #ERROR} and {@link #FATAL}.
   * @param message the message which should be logged.
   */
  public void log(int level, String message);

  /*
  public final Logger SIMPLE_LOGGER=new Logger(){
      public boolean isEnabled(int level){return true;}
      public void log(int level, String message){System.err.println(message);}
    };
  final Logger DEVNULL=new Logger(){
      public boolean isEnabled(int level){return false;}
      public void log(int level, String message){}
    };
  */
}
